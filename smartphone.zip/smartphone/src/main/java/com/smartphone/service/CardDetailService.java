package com.smartphone.service;

import com.smartphone.model.CardDetail;



public interface CardDetailService {

    void addCardDetail (CardDetail carddetail);

}
