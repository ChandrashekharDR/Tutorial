package com.smartphone.dao;

import com.smartphone.model.CardDetail;


public interface CardDetailDao {

    void addCardDetail (CardDetail cardDetail);

}
