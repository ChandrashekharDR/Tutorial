package com.smartphone.dao;

import com.smartphone.model.UserOrder;


public interface OrderDao {

    void addOrder(UserOrder userOrder);

}
